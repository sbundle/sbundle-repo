# exit

Exits the shell.

## Example use

```
...
$ exit
```