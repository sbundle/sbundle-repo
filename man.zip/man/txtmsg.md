# txtmsg

Send an text message to sombody.

## Example use

```
$ txtmsg 1234567890 hello
```