# head

Gets the first *n* lines of a file.
*n* defaults to 10.

## Example Usage

```
$ head ./shortterm_history.txt
ls .
cd ..
ls .
cd ./etc
ls .
cat ./environment.sh
cat ./username.txt
cat ./trusted.txt
cd $HOME
ls .
$ head -n 3 /ROOTFS/share/man/pwd.md
# pwd

Prints the current working directory.
```