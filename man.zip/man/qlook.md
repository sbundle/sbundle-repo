# qlook

Displays a file in quick look.

## Example use

```
$ cd /ROOTFS/bin

$ qlook ./man.sh
[opens quick look dialog displaying contents of 'man.sh']
```