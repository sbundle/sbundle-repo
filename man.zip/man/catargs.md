# catargs

Concatenate multiple strings together, and store to a variable.

## Options

-e [string]: encode `string` with double quotes. \ -> \\, " -> \"

## Example Use

```
$ catargs x "The home directory is " $HOME

$ echo $x
The home directory is /ROOTFS/home/matthew
$ set y "document.write(\"the argument is: \\\"\"+arg+\"\\\"\");"

$ catargs scr "<script>let arg=\"" $x "\"; " $y "</script>"
```