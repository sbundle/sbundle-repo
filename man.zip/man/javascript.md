# javascript

ShortTerm uses WebKit internally to run javascript, so it's limited to what WebKit can do in a `data:` URI.

ShortTerm has a javascript preprocessor to combine files like modules, here is an example:

`/ROOTFS/lib/library.js`:
```
function println(text) {
 document.write(text + "<br>");
}
#export println
```

`/ROOTFS/bin/saystuff.js`:
```
#require "library.js"
const lib = module["library"];
lib.println("Hello");
let x = 5 + 8;
lib.println("x is "+x);
```

If you run `saystuff.js`, it will display
```
Hello
x is 13
```