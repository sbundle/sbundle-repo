# javascript

ShortTerm uses WebKit internally to run javascript, so it's limited to what WebKit can do in a `data:` URI.

ShortTerm has a javascript preprocessor to combine files like modules, here is an example:

`/ROOTFS/lib/library.js`:
```
function println(text) {
 document.write(text + "<br>");
}
#export println
```

`/ROOTFS/bin/saystuff.js`:
```
#require "library.js"
const lib = module["library"];
lib.println("Hello");
let x = 5 + 8;
lib.println("x is "+x);
```

If you run `saystuff.js`, it will display
```
Hello
x is 13
```

You can also read arguments from javascript files, like this:

`/ROOTFS/bin/eq.js`:
```
document.write(argv[0] + "=" + argv[1]);
```

if you run it like `eq.js 5 3+2` it will output "5=3+2".