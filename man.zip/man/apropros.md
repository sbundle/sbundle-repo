# apropros

Search manpages for a phrase or regex using grep.

## Example use

```
$ apropros sort
uniq {
... (matching lines)
}
sort {
... (matching lines)
}
```