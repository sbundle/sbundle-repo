# out2file

Save the output of a command to a file.

## Example Usage

```
$ cd /ROOTFS/share/

$ out2file ./listing.txt "ls ."

$ cat ./listing.txt
packages
man
doc
```