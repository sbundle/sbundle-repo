# uniq

Print unique or duplicated lines in a sorted file.

## Options

-u: unique lines
-d: duplicated lines

## Example Usage

```
$ cat ./animals.txt
bear
cat
dog
horse
bear
pig
horse
$ out2file .tmp.txt "sort ./animals.txt"

$ uniq -u .tmp.txt
cat
dog
pig
```