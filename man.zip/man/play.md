# play

Play a sound file

## Example use

```
$ play ./playlist/taswell.m4a
```