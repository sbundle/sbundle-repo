# shell

ShortTerm provides a limited shell scripting environment.

You can run many UN*X commands, type `ls /ROOTFS/share/man` to list them, along with other system manual pages.

You can enter arguments in two ways:
 * no quotes: no spaces or quotes allowed
 * quoted: spaces allowed, and sub-quotes must be escaped

Here is an example:
`echo hello`
and with quotes:
`echo "hello world"`

Multiple substitutions take place. They are as follows:
 * any argument starting with a period will get path-substituted, like `ls .` -> `ls /ROOTFS/home/matthew/`
 * any argument starting with a dollar sign will get replaced with a variable's value, like `echo $HOME` -> `echo /ROOTFS/home/matthew/'

If you run a shell script, it will automatically have a variable for each argument:
`script.sh arg1` will output `the argument is arg1` for the script.sh defined below.

`script.sh`:
```
catargs message "the argument is" $1
echo $message
```