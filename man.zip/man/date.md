# date

Prints the current date.

## Example Usage

```
$ date
Sun 17 Aug 2025 03:28:24 PM CDT
```