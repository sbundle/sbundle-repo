# expr

Calculate expression (warning: if the expression is invalid, an error will occur).

## Example use

```
$ expr "56 / 2 + 5"
33
$ expr "8 * 24"
192
```