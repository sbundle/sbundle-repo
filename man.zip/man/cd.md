# cd

Sets the current working directory.

## Example use

```
$ cd /ROOTFS/bin

$ cd ../share/packages

$ cd $HOME

$ cd /ROOTFS/

$ cd ./lib
```