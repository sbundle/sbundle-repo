# run

Runs a shortcut, with two extra features.

- decodes arguments with json, so dictionaries and lists can be entered.
- keeps shortterm running even if an error occurs.

**WARNING: x-callback is extremely buggy, consider converting your app to a command line tool instead of using this.**

You will need to enter or exit/re-enter the shortcuts app for shortterm to continue, because if the x-callback returns early, shortterm shouldn't block the running shortcut.

## Example Use

```
$ run "Sunbundler"

[MyShortcut takes a dictionary with a key called 'message', and returns text.]

$ run "MyShortcut" "{\"message\": \"hello\"}"

user, I got a message for you: 'hello'
```