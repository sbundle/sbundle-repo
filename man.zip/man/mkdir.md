# mkdir

Make a directory.

## Example use

```
$ cd $HOME

$ mkdir ./mydir
```