# touch

Create an empty file.

## Example Use

```
$ cd /ROOTFS/etc

$ touch ./config.txt
```