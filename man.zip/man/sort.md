# sort

Sort a newline seperated list alphabetically.

## Options

-r: sort in reverse

## Example Usage

```
$ sort ./animals.txt
bear
cat
dog
horse
pig
$ sort -r ./animals.txt
pig
horse
dog
cat
bear
```