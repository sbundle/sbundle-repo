# cp

Copies a file to another location.

## Example usage

```
$ cd $HOME

$ cp ./doc.txt /ROOTFS/share/doc/page.md
```