# mail

Send an email to sombody.

## Example use

```
$ mail -s "Test email" user@example.com -
[user types email body into stdin]

$ cd $HOME

$ mail -s "Document" user2@example.com ./documemt.md
```