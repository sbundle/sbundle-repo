# pwd

Prints the current working directory.

## Example use

```
$ pwd
/ROOTFS/bin/
```