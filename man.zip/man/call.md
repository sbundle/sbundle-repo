# call

Call a phone number.

## Example usage

```
$ call 1234567890
... (call starts)
```