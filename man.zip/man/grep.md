# grep

Search a file for a pattern.

## Example use

```
$ grep "[Hh]ello" ./greeting.txt
Hello, how are you today?
$ out2file .tmp.txt "ls ."

$ grep .js .tmp.txt
saystuff.js
my.js
```