# mv

Move a file from one location to another. Can also be used to rename files.

## Example Use

```
$ cd $HOME

$ mv ./scr.sh /ROOTFS/bin/scr.sh

$ mv ./doc.txt ./x.txt
```