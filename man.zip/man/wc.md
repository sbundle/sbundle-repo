# wc

Count characters, lines, or words in a file

## Options

-c / -m: count characters
-l: count lines
-w: count words

## Example Usage

```
$ cat ./m.txt
hello world
goodbye world
$ wc -c ./m.txt
25
$ wc -l ./m.txt
2
```