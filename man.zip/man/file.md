# file

Get the file type of a fille using magic bytes.

## Example usage

```
$ wget example.com ./x.json

$ file ./x.json
(text) HTML
```