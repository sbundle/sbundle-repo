# set

Sets a shell variable.

## Example Use

```
$ set myvar hi

$ echo $myvar
hi
```