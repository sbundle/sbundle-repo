# tail

Gets the last *n* lines of a file.
*n* defaults to 10.

## Example Usage

    $ tail ./shortterm_history.txt
    ls .
    cd ..
    ls .
    cd ./etc
    ls .
    cat ./environment.sh
    cat ./username.txt
    cat ./trusted.txt
    cd $HOME
    ls .
    $ tail -n 2 /ROOTFS/share/man/pwd.md
    /ROOTFS/bin/
    ```