## rmdir

Alias to rm; view rm's manual instead.