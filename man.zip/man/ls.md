# ls

Lists a directory.

## Options

-l: long listing
-R: list recursively

## Example Usage

```
$ ls /ROOTFS/
man
home
temp
bin
etc
lib
share
$ ls -l /ROOTFS/etc
[I know total # is supposed to dispay memory usage, but this implementation shows the file count.]
total 3
-rw-r--r-- matthew matthew 7 Jul 21 18:24 username.txt
-rw-r--r-- matthew matthew 4 Jul 26 10:28 environment.sh
-rw-r--r-- matthew matthew 85 Aug 17 00:22 trusted.txt
$ ls -R /ROOTFS/share/doc
libHelloWorld1.0.0
helloWorld1.0.0
ShortTerm1.0.0
/ROOTFS/share/doc/libHelloWorld1.0.0:
README.md
/ROOTFS/share/doc/helloWorld1.0.0:
README.md
/ROOTFS/share/doc/ShortTerm1.0.0:
README.md
```