# file2var

Stores a file's contents into a variable.

## Example Usage

```
$ file2var page /ROOTFS/share/man/date.md

$ out2var now "date"

$ catargs page $page "
 
 ### indexed at " $now

$ in2file /ROOTFS/share/man/date.md $page
```