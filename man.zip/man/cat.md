# cat

Combine files and print their contents.

## Example Usage

```
$ cd /ROOTFS/etc

$ cat ./username.txt
matthew
$ cat ./username.txt ./environment.sh
matthew
ls .
```