# base64

base64 encode or decode a file.

## Options

-d: decode

## Example Usage

```
$ out2file ./udb.b64 "base64 ./udb.txt"

$ base64 -d ./udb.b64
example file
test data:
1
2
3
```