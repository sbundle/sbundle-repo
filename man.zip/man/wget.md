# wget

Fetch a file from online to a local file.

## Example use

```
$ cd $HOME

$ wget https://example.com ./ex.html
```