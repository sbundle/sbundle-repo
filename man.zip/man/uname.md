# uname

Print system info.

## Options

-m: print machine hardware name
-n: print nodename (localhost)
-r: print operating system release
-s: print operating system name
-a: all other options

## Example Usage

```
$ uname -a
iPhone 11 localhost iOS 26.1 Darwin
```