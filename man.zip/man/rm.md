# rm

Remove a file or directory.

## Example Usage

```
$ cd $HOME

$ touch ./file

$ rm ./file
```