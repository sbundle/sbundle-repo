# echo

Print text.

## Example Usage

```
$ echo hi
hi
```