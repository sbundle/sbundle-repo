# in2file

Save an argument to a file.

## Example Use

```
$ in2file ./hm.txt $HOME

$ cat ./hm.txt
/ROOTFS/home/matthew/
```